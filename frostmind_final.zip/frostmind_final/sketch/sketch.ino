
#include <Arduino_Modulino.h>

ModulinoMovement movement;
ModulinoBuzzer buzzer;

float oldX = 0, oldY = 0, oldZ = 0;
bool initialized = false;

unsigned long lastBeep = 0;

void setup() {
  Serial.begin(115200);
  Modulino.begin();
  movement.begin();
  buzzer.begin();

  Serial.println("FrostMind Hardware Ready!");
}

void loop() {
  movement.update();

  float x = movement.getX();
  float y = movement.getY();
  float z = movement.getZ();

  if (!initialized) {
    oldX = x;
    oldY = y;
    oldZ = z;
    initialized = true;
    return;
  }

  float change = abs(x - oldX)
               + abs(y - oldY)
               + abs(z - oldZ);

  oldX = x;
  oldY = y;
  oldZ = z;

  if (change > 0.15 &&
      millis() - lastBeep > 3000) {

    Serial.println("FrostMind: Door movement detected!");
    buzzer.tone(1000, 200);

    lastBeep = millis();
  }

  delay(100);
}

